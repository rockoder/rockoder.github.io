#!/bin/bash

HOST=$1
PORT=$2

if [ -z "$HOST" ];
then
    HOST=localhost;
fi

if [ -z "$PORT" ];
then
    PORT=8080;
fi

# Driver location PUT request sequential for 10 times
ab -n 10 -c 1 -u put.txt -T application/json http://${HOST}:${PORT}/drivers/1/location

# Driver location PUT request 1000 concurrent requests for total 5000 times
ab -n 5000 -c 1000 -u put.txt -T application/json http://${HOST}:${PORT}/drivers/1/location

# Customer driver location GET request sequential for 10 times
ab -n 10 -c 1 "http://${HOST}:${PORT}/drivers?latitude=1&longitude=1&radius=500&limit=10"

# Customer driver location GET request 20 concurrent requests for total 100 times
ab -n 100 -c 20 "http://${HOST}:${PORT}/drivers?latitude=1&longitude=1&radius=500&limit=10"
