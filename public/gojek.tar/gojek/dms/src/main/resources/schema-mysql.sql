CREATE TABLE driver
(
  id bigint NOT NULL AUTO_INCREMENT,
  location POINT,
  accuracy FLOAT,
  CONSTRAINT driver_pkey PRIMARY KEY (id)
);
