# noinspection SqlNoDataSourceInspectionForFile

INSERT INTO driver VALUES (NULL, ST_PointFromText('POINT(12.97161923  77.59463452)'), 0.7);
INSERT INTO driver VALUES (NULL, ST_PointFromText('POINT(1 2)'), 0.6);
INSERT INTO driver VALUES (NULL, ST_PointFromText('POINT(1 3)'), 0.8);
INSERT INTO driver VALUES (NULL, ST_PointFromText('POINT(1 4)'), 0.8);
INSERT INTO driver VALUES (NULL, ST_PointFromText('POINT(2 2)'), 0.8);
INSERT INTO driver VALUES (NULL, ST_PointFromText('POINT(3 3)'), 0.8);
INSERT INTO driver VALUES (NULL, ST_PointFromText('POINT(4 4)'), 0.8);