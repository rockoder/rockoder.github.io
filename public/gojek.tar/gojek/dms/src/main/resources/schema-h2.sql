-- Register aliases for spatial functions
CREATE ALIAS CreateSpatialIndex for "geodb.GeoDB.CreateSpatialIndex";
CREATE ALIAS DropSpatialIndex for "geodb.GeoDB.DropSpatialIndex";
CREATE ALIAS EnvelopeAsText for "geodb.GeoDB.EnvelopeAsText";
CREATE ALIAS GeometryType for "geodb.GeoDB.GeometryType";
CREATE ALIAS ST_Area FOR "geodb.GeoDB.ST_Area";
CREATE ALIAS ST_AsEWKB FOR "geodb.GeoDB.ST_AsEWKB";
CREATE ALIAS ST_AsEWKT FOR "geodb.GeoDB.ST_AsEWKT";
CREATE ALIAS ST_AsHexEWKB FOR "geodb.GeoDB.ST_AsHexEWKB";
CREATE ALIAS ST_AsText FOR "geodb.GeoDB.ST_AsText";
CREATE ALIAS ST_BBOX FOR "geodb.GeoDB.ST_BBox";
CREATE ALIAS ST_Buffer FOR "geodb.GeoDB.ST_Buffer";
CREATE ALIAS ST_Centroid FOR "geodb.GeoDB.ST_Centroid";
CREATE ALIAS ST_Crosses FOR "geodb.GeoDB.ST_Crosses";
CREATE ALIAS ST_Contains FOR "geodb.GeoDB.ST_Contains";
CREATE ALIAS ST_DWithin FOR "geodb.GeoDB.ST_DWithin";
CREATE ALIAS ST_Disjoint FOR "geodb.GeoDB.ST_Disjoint";
CREATE ALIAS ST_Envelope FOR "geodb.GeoDB.ST_Envelope";
CREATE ALIAS ST_Equals FOR "geodb.GeoDB.ST_Equals";
CREATE ALIAS ST_GeoHash FOR "geodb.GeoDB.ST_GeoHash";
CREATE ALIAS ST_GeomFromEWKB FOR "geodb.GeoDB.ST_GeomFromEWKB";
CREATE ALIAS ST_GeomFromEWKT FOR "geodb.GeoDB.ST_GeomFromEWKT";
CREATE ALIAS ST_GeomFromText FOR "geodb.GeoDB.ST_GeomFromText";
CREATE ALIAS ST_GeomFromWKB FOR "geodb.GeoDB.ST_GeomFromWKB";
CREATE ALIAS ST_Intersects FOR "geodb.GeoDB.ST_Intersects";
CREATE ALIAS ST_IsEmpty FOR "geodb.GeoDB.ST_IsEmpty";
CREATE ALIAS ST_IsSimple FOR "geodb.GeoDB.ST_IsSimple";
CREATE ALIAS ST_IsValid FOR "geodb.GeoDB.ST_IsValid";
CREATE ALIAS ST_MakeBox2D FOR "geodb.GeoDB.ST_MakeBox2D";
CREATE ALIAS ST_Overlaps FOR "geodb.GeoDB.ST_Overlaps";
CREATE ALIAS ST_SRID FOR "geodb.GeoDB.ST_SRID";
CREATE ALIAS ST_SetSRID FOR "geodb.GeoDB.ST_SetSRID";
CREATE ALIAS ST_Simplify FOR "geodb.GeoDB.ST_Simplify";
CREATE ALIAS ST_Touches FOR "geodb.GeoDB.ST_Touches";
CREATE ALIAS ST_Within FOR "geodb.GeoDB.ST_Within";
CREATE ALIAS ST_Distance FOR "geodb.GeoDB.ST_Distance";
CREATE ALIAS ST_Distance_Sphere FOR "geodb.GeoDB.ST_Distance";

CREATE TABLE driver
(
  id bigint NOT NULL AUTO_INCREMENT,
  location blob,
  accuracy FLOAT,
  CONSTRAINT driver_pkey PRIMARY KEY (id)
);
