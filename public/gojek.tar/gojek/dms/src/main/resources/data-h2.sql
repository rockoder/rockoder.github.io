-- noinspection SqlNoDataSourceInspectionForFile

INSERT INTO driver VALUES (NULL, ST_GeomFromText('POINT(12.97161923  77.59463452)', 4326), 0.7);
INSERT INTO driver VALUES (NULL, ST_GeomFromText('POINT(1 2)', 4326), 0.6);
INSERT INTO driver VALUES (NULL, ST_GeomFromText('POINT(1 3)', 4326), 0.8);
INSERT INTO driver VALUES (NULL, ST_GeomFromText('POINT(1 4)', 4326), 0.8);
INSERT INTO driver VALUES (NULL, ST_GeomFromText('POINT(2 2)', 4326), 0.8);
INSERT INTO driver VALUES (NULL, ST_GeomFromText('POINT(3 3)', 4326), 0.8);
INSERT INTO driver VALUES (NULL, ST_GeomFromText('POINT(4 4)', 4326), 0.8);