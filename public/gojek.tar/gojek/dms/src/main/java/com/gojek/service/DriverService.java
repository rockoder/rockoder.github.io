package com.gojek.service;

import com.gojek.entity.Driver;
import com.gojek.entity.DriverResponse;

import java.util.List;

/**
 * Created by Ganesh Pagade.
 */

public interface DriverService {
    public List<Driver> findAll();

    public List<DriverResponse> findAllNearBy(Float latitude, Float longitude, Float radius, Integer limit);

    Driver findById(Long driverId);

    Driver updateDriver(Driver driver);
}
