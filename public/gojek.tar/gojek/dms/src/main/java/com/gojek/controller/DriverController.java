package com.gojek.controller;

import com.gojek.entity.Driver;
import com.gojek.entity.DriverResponse;
import com.gojek.entity.ErrorsMessageDTO;
import com.gojek.entity.Location;
import com.gojek.service.DriverService;
import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import java.net.URI;
import java.util.List;
import java.util.Set;

/**
 * Created by Ganesh Pagade.
 */

@RestController
@Validated
@RequestMapping(value = "/drivers")
public class DriverController {

    private DriverService driverService;

    @Autowired
    public DriverController(DriverService driverService) {
        this.driverService = driverService;
    }

    @RequestMapping(method = RequestMethod.GET)
    ResponseEntity<List<DriverResponse>> getDrivers(
                                            @Valid @NotNull
                                            @DecimalMin(value = "-90", message = "Latitude should be between +/-90.")
                                            @DecimalMax(value = "90", message = "Latitude should be between +/-90.")
                                            @RequestParam Float latitude,

                                            @Valid @NotNull
                                            @DecimalMin(value = "-180", message = "Latitude should be between +/-180.")
                                            @DecimalMax(value = "180", message = "Latitude should be between +/-180.")
                                            @RequestParam Float longitude,

                                            @RequestParam(required = false, defaultValue = "500.0f") Float radius,
                                            @RequestParam(required = false, defaultValue = "10") Integer limit) {

        List<DriverResponse> driverResponseList = driverService.findAllNearBy(latitude, longitude, radius, limit);

        if (null == driverResponseList) {
            return new ResponseEntity<List<DriverResponse>>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<List<DriverResponse>>(driverResponseList, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{driver}")
    ResponseEntity<Driver> getDriver(
            @Valid @NotNull
            @PathVariable Long driver) {
        Driver d = driverService.findById(driver);

        if (null == d) {
            return new ResponseEntity<Driver>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<Driver>(d, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST)
    ResponseEntity<Driver> createDriver(@RequestBody Location location) {
        return updateDriver(location, null);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/{driver}/location")
    ResponseEntity<Driver> updateDriver(@Validated @RequestBody Location location,
                                    @Valid
                                    @Range(min = 1, max = 50000, message = "Driver ID should be between 1 to 50000.")
                                    @PathVariable Long driver) {

        Driver tempDriver = new Driver(new GeometryFactory().createPoint(
                                            new Coordinate(location.getLatitude(),
                                                           location.getLongitude())),
                                        location.getAccuracy());

        // Note: Current PUT will create Driver if id is valid but entity does not exists.
        // Ideally an error should be thrown. Separate POST should be used for entity creation.

        tempDriver.setId(driver);

        tempDriver = driverService.updateDriver(tempDriver);

        URI uriOfUpdatedDriver = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/drivers/{driver}")
                .buildAndExpand(tempDriver.getId())
                .toUri();

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setLocation(uriOfUpdatedDriver);

        return new ResponseEntity<Driver>(null, httpHeaders, HttpStatus.OK);
    }

    @ExceptionHandler(value = { MethodArgumentNotValidException.class })
    @ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
    public ErrorsMessageDTO handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        return new ErrorsMessageDTO(e.getBindingResult().getFieldError().getDefaultMessage());
    }

    @ExceptionHandler(value = { ConstraintViolationException.class })
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ErrorsMessageDTO handleResourceNotFoundException(ConstraintViolationException e) {
        Set<ConstraintViolation<?>> violations = e.getConstraintViolations();
        StringBuilder strBuilder = new StringBuilder();
        for (ConstraintViolation<?> violation : violations ) {
            strBuilder.append(violation.getMessage());
        }
        return new ErrorsMessageDTO(strBuilder.toString());
    }
}
