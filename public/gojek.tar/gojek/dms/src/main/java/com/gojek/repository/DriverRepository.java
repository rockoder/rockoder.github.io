package com.gojek.repository;

import com.gojek.entity.Driver;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * Created by Ganesh Pagade.
 */

public interface DriverRepository extends PagingAndSortingRepository<Driver, Long>,
                                          NearByDriver {
}
