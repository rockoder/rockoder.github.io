package com.gojek.entity;

import java.util.ArrayList;

/**
 * Created by Ganesh Pagade.
 */
public class ErrorsMessageDTO {
    private ArrayList<String> errors = new ArrayList<>();

    ErrorsMessageDTO() {
    }

    public ErrorsMessageDTO(String error) {
        this.errors.add(error);
    }

    public ArrayList<String> getErrors() {
        return errors;
    }

    public void setErrors(String errors) {
        this.errors.add(errors);
    }
}
