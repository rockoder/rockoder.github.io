package com.gojek.entity;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;

/**
 * Created by Ganesh Pagade.
 */

public class Location {
    @NotNull
    @DecimalMin(value = "-90", message = "Latitude should be between +/-90.")
    @DecimalMax(value = "90", message = "Latitude should be between +/-90.")
    private Float latitude;

    @NotNull
    @DecimalMin(value = "-180", message = "Longitude should be between +/-180.")
    @DecimalMax(value = "180", message = "Longitude should be between +/-180.")
    private Float longitude;

    private Float accuracy;

    Location() {
    }

    public Location(Float latitude, Float longitude, Float accuracy) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.accuracy = accuracy;
    }

    public Float getLatitude() {
        return latitude;
    }

    public void setLatitude(Float latitude) {
        this.latitude = latitude;
    }

    public Float getLongitude() {
        return longitude;
    }

    public void setLongitude(Float longitude) {
        this.longitude = longitude;
    }

    public Float getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(Float accuracy) {
        this.accuracy = accuracy;
    }
}
