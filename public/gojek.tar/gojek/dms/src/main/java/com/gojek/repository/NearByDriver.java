package com.gojek.repository;

import com.gojek.entity.DriverDTO;

import java.util.List;

/**
 * Created by Ganesh Pagade.
 */
public interface NearByDriver {
    List<DriverDTO> findAllNearBy(Float latitude, Float longitude, Float radius, Integer limit);
}
