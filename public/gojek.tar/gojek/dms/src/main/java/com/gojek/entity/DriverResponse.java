package com.gojek.entity;

/**
 * Created by Ganesh Pagade.
 */
public class DriverResponse {
    private Long id;
    private Double latitude;
    private Double longitude;
    private Double distance;

    public DriverResponse() {
    }

    public DriverResponse(DriverDTO driverDTO) {
        this.id = driverDTO.getId();
        this.latitude = driverDTO.getLocation().getCoordinate().getOrdinate(0);
        this.longitude = driverDTO.getLocation().getCoordinate().getOrdinate(1);
        this.distance = driverDTO.getDistance();
    }

    public DriverResponse(Long id, Double latitude, Double longitude, Double distance) {
        this.id = id;
        this.latitude = latitude;
        this.longitude = longitude;
        this.distance = distance;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }
}
