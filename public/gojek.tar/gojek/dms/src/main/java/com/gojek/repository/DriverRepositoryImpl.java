package com.gojek.repository;

import com.gojek.entity.DriverDTO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * Created by Ganesh Pagade.
 */
public class DriverRepositoryImpl implements NearByDriver {

    @PersistenceContext
    EntityManager entityManager;

    public List<DriverDTO> findAllNearBy(Float latitude, Float longitude, Float radius, Integer limit) {

        String queryStr = "SELECT id, location, ST_Distance_Sphere(point(?1,?2), location) as distance " +
                                "from driver " +
                                "where ST_Distance_Sphere(point(?3,?4), location)  <= ?5 " +
                                "limit ?6";

        Query query = entityManager.createNativeQuery(queryStr, DriverDTO.class);

        query.setParameter(1, latitude);
        query.setParameter(2, longitude);
        query.setParameter(3, latitude);
        query.setParameter(4, longitude);
        query.setParameter(5, radius);
        query.setParameter(6, limit);

        return query.getResultList();
    }
}
