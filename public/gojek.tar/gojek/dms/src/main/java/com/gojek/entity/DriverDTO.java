package com.gojek.entity;

import com.vividsolutions.jts.geom.Point;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created by Ganesh Pagade.
 */
@Entity
public class DriverDTO {
    @Id
    private Long id;

    @Column(columnDefinition = "Point")
    private Point location;

    private Double distance;

    DriverDTO() {
    }

    public DriverDTO(Long id, Point location, Double distance) {
        this.id = id;
        this.location = location;
        this.distance = distance;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Point getLocation() {
        return location;
    }

    public void setLocation(Point location) {
        this.location = location;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
