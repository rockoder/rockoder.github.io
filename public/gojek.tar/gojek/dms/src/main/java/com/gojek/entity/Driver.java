package com.gojek.entity;

import com.vividsolutions.jts.geom.Point;

import javax.persistence.*;

/**
 * Created by Ganesh Pagade.
 */

@Entity
public class Driver {

    @Id
    @Column(name = "id", unique = true, nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "Point")
    private Point location;

    private float accuracy;

    public Driver() {
    }

    public Driver(Point location, float accuracy) {
        this.location = location;
        this.accuracy = accuracy;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Point getLocation() {
        return location;
    }

    public void setLocation(Point location) {
        this.location = location;
    }

    public float getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(float accuracy) {
        this.accuracy = accuracy;
    }
}
