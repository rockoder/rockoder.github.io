package com.gojek.service;

import com.gojek.entity.Driver;
import com.gojek.entity.DriverDTO;
import com.gojek.entity.DriverResponse;
import com.gojek.entity.Location;
import com.gojek.repository.DriverRepository;
import com.vividsolutions.jts.geom.Point;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ganesh Pagade.
 */

@Service
@Transactional
public class DriverServiceImpl implements DriverService {

    private DriverRepository driverRepository;

    @Autowired
    public DriverServiceImpl(DriverRepository driverRepository) {
        this.driverRepository = driverRepository;
    }

    @Override
    public List<DriverResponse> findAllNearBy(Float latitude, Float longitude, Float radius, Integer limit) {
        List<DriverDTO> driverDTOList = (List<DriverDTO>) driverRepository.findAllNearBy(latitude, longitude, radius, limit);
        List<DriverResponse> driverResponseList = null;

        if (driverDTOList != null && driverDTOList.size() != 0) {
            driverResponseList = new ArrayList<DriverResponse>();

            for (DriverDTO d : driverDTOList) {
                driverResponseList.add(new DriverResponse(d));
            }
        }

        return  driverResponseList;
    }

    @Override
    public List<Driver> findAll() {
        List<Driver> driverList = (List<Driver>) driverRepository.findAll();

        if (driverList != null && driverList.size() != 0) {
            return  driverList;
        }

        throw new RuntimeException(); // TODO
    }

    @Override
    public Driver findById(Long driverId) {
        Driver driver = driverRepository.findOne(driverId);

        return driver;
    }

    @Override
    public Driver updateDriver(Driver driver) {
        return this.driverRepository.save(driver);
    }
}
