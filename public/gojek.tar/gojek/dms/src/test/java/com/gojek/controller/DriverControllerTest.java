package com.gojek.controller;

import com.gojek.entity.Driver;
import com.gojek.entity.Location;
import com.gojek.service.DriverService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by Ganesh Pagade.
 */

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("dev")
@Transactional
public class DriverControllerTest {

    private static final Long DRIVER_ID = 2L;

    @Autowired
    private DriverService driverService;

    @Test
    public void getDriverLocation() throws Exception {
        DriverController dc = new DriverController(driverService);
        ResponseEntity<Driver> rd = dc.getDriver(DRIVER_ID);

        Assert.assertTrue(rd.getStatusCode() == HttpStatus.OK);
        Assert.assertTrue(rd.getBody().getLocation().getCoordinate().getOrdinate(0) == 1);
        Assert.assertTrue(rd.getBody().getLocation().getCoordinate().getOrdinate(1) == 2);
    }

    private void saveDriver(Long driverId) throws  Exception {
        float newLat = 3.0f;
        float newLon = 4.0f;
        float newAcc = 0.6f;

        DriverController dc = new DriverController(driverService);
        Location location = new Location(newLat, newLon, newAcc);

        ResponseEntity<Driver> d = dc.updateDriver(location, driverId);
        Assert.assertTrue(d.getStatusCode() == HttpStatus.OK);
    }

    @Test
    public void createDriver() throws Exception {
        saveDriver(null);
    }
    @Test
    public void updateDriverLocation() throws Exception {
        saveDriver(DRIVER_ID);
    }
}
