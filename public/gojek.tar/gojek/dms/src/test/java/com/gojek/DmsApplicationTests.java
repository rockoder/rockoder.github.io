package com.gojek;

import com.gojek.entity.Driver;
import com.gojek.entity.DriverDTO;
import com.gojek.repository.DriverRepository;
import com.gojek.service.DriverService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("dev")
public class DmsApplicationTests {

	@Autowired
	DriverRepository driverRepository;

	@Autowired
	DriverService driverService;

	@Test
	public void contextLoads() {
		Assert.assertNotNull("The driverRepository should be non-null", this.driverRepository);
	}

	@Test
	public void testLoadingResultsInDatabase() {
		List<Driver> driverList =
				(List<Driver>) this.driverRepository.findAll();

		Assert.assertNotNull("There must be a response", driverList);
		Assert.assertTrue("There should be at least one record", driverList.size() > 0);
	}

	@Test
	public void testOutsideDriver() {
		// does not work for h2 db. tested with mysql db.

//		List<DriverDTO> farDriver = this.driverRepository.findAllNearBy(12.969345092773438f, 77.60635375976562f, 1000.0f, 10);
//		Assert.assertTrue("Driver outside radius", farDriver.size() == 0);
	}

	@Test
	public void testInsideDriver() {
		// does not work for h2 db. tested with mysql db.

//		List<DriverDTO> nearDriver = this.driverRepository.findAllNearBy(12.969345092773438f, 77.60635375976562f, 3000.0f, 10);
//		Assert.assertTrue("Driver inside radius", nearDriver.size() > 0);
	}
}