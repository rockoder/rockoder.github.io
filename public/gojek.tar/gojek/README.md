# Introduction

This repository contains the solution for the "GOJEK Where is My Driver-2017" problem. Refer `GOJEK Where is My Driver-2017.pdf` for more details about the problem.

# Tech Stack Details

- The solution is based on Spring Boot. Spring Boot makes implementation of RESTful web services easy, eliminating writing boiler plate code. Familiarity of Java and Spring and time constraint was also considered while making the selection.
- It uses MySQL for DB. MySQL with spatial extensions suffices for the solutions need.
- It used Docker for deployment. Docker helps in easy, consistent deployment of the application. With Docker Compose the application can be up and running with single command.
- Apache HTTP server benchmarking tool (`ab`) is used for basic benchmarking the API performance.

# Infrastructure Requirements

- To execute, a Linux based OS (Ubuntu recommended) with latest Docker installed is the only requirement. Docker image takes care of all other dependencies.
- Please refer following steps for Docker installation on Ubuntu: 
	- http://www.rockoder.com/introduction_to_docker/#/6
	- http://www.rockoder.com/introduction_to_docker/#/6/1
	- http://www.rockoder.com/introduction_to_docker/#/11/1
- Additionally `ab`, the Apache HTTP server benchmarking tool can be installed to execute the load testing scripts. Following command can be used to install on Ubuntu:
`sudo apt-get install apache2-utils`

- To build the code, Java 8 and Maven was used.

# Step to Quickly Try the Application

All steps below assumes the gojek.tar is copied to the home directory (~/) of the user.

## Method 1. Using Docker

```
$ cd ~
$ tar -xvf gojek.tar
$ cd ~/gojek/deployment
$ docker-compose up -d
```

You can now fire REST APIs to the service on port `8080`. For example:
`http://localhost:8080/drivers?latitude=12.97161923&longitude=77.59463452&radius=500&limit=10`

## Method 2. Sample Service Running on Google Cloud

The application is running on Google Cloud instance and REST APIs can be fire rightaway. Example:
`http://130.211.212.168:8080/drivers?latitude=12.97161923&longitude=77.59463452&radius=500&limit=10`

# Detailed Steps

- Extract code
```
$ cd ~
$ tar -xvf gojek.tar
```

- To compile, unit test and packaging
```
$ cd ~/gojek/dms
$ mvn clean package
```

- Run the Docker containers
```
$ cd ~/gojek/deployment
$ docker-compose up -d
```

- Run the load test script. Usage `loadtest.sh hostname port`. Default hostname is localhost. Default port is 8080.
```
$ cd ~/gojek/loadtest
$ ./loadtest.sh
```

- To cleanup the setup
```
$ cd ~/gojek/deployment
$ docker-compose down
```
